package hcl.kdrp.sailpoint.iCIMSSailPointFeed;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ICimsSailPointFeedApplicationTests {

	@Test
	public void contextLoads() {
	}

}
