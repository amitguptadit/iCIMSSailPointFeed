package hcl.kdrp.sailpoint.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@PropertySource("classpath:SailPoint.properties")
public class SailPointFeed {
	
	@Value("${sailpointfeed.file.location}")
	public String sailpointFeedFileName;
	
/*	private static String sailpointFeedFileName;
	@Value("${sailpointfeed.file.location}")
	public void setSailpointFeedFileName(String sailpointFeedFileName) {
		this.sailpointFeedFileName = sailpointFeedFileName;
	}
*/    
	public void printProperties(){
		System.out.println("sailpointFeedFileName: "+sailpointFeedFileName);  
	}
}
