package hcl.kdrp.sailpoint.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

@Service
public class SailPointFeedUtil {
	private static final String COMMA_DELIMITER = ",";
	public List<List<String>> getPersonName(String dirLoc) {
		String name="";
		List<String> firstNameOfPerson = new ArrayList<>();
		List<String> lastNameOfPerson = new ArrayList<>();
		List<String> middleNameOfPerson = new ArrayList<>();
		List<String> personGSN = new ArrayList<>();
		List<List<String>> records = new ArrayList<>();
		
		File fl = new File(dirLoc+"/in/iCIMSSailPointFeed.csv");
		if(!(fl.exists())) {
			System.out.println("File does not exits on path :"+dirLoc+"/in/iCIMSSailPointFeed.csv");
			System.exit(0);
		}
			
		try (BufferedReader br = new BufferedReader(new FileReader(dirLoc+"/in/iCIMSSailPointFeed.csv"))) {
		    String line;
		    int lineNumber = 0;
		    while ((line = br.readLine()) != null) {
		    	lineNumber=lineNumber+1;
		        String[] values = line.split(COMMA_DELIMITER);
		        int cnt = 0;
		        for(String str:values) {
		        	cnt = cnt+1;
		        	if(cnt==3) {
		        		//fisrtname
		        		firstNameOfPerson.add(str);
		        	}
		        	else if(cnt==4) {
		        		//lastname
		        		lastNameOfPerson.add(str);
		        	}
		        	else if(cnt==5) {
		        		//middlename
		        		middleNameOfPerson.add(str);
		        	}
		        	//GUPAX028
		        }
		       
		    }
		    
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		records.add(firstNameOfPerson);
		records.add(lastNameOfPerson);
		records.add(middleNameOfPerson);
		System.out.print("PersonName :"+records.get(0).size()+"#"+records.get(1).size()+"#"+records.get(2));
		
		return records;
	}
	//****************[ Create Person GSN File ]********************************************
	public List<String> getPersonName(List<List<String>> personRecords,String dirLoc){
		List<String> firstNameOfPerson = personRecords.get(0);
		List<String> lastNameOfPerson = personRecords.get(1);
		List<String> middleNameOfPerson = personRecords.get(2);
		List<String> personGSN = new ArrayList<>();
		for(int i=0;i<159;i++) {
			//System.out.println("PersonName - >"+records.get(0).size()+"#"+records.get(1).size()+"#"+records.get(2).size());
			String gsnName=lastNameOfPerson.get(i).substring(0,3)+firstNameOfPerson.get(i).substring(0,1);
			if(!middleNameOfPerson.get(i).equalsIgnoreCase("")) {
				gsnName=gsnName+middleNameOfPerson.get(i).substring(0,1);
			} else {
				gsnName=gsnName+"X";
			}
			try {
				if(i>0 && i%10==0) {
					Files.write(Paths.get(dirLoc+"/output/output.csv"),(gsnName.toUpperCase()+"\n").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
				}else {
					Files.write(Paths.get(dirLoc+"/output/output.csv"),(gsnName.toUpperCase()+",").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
				}
				
				
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			personGSN.add(gsnName.toUpperCase());
		}
		return personGSN;
	}
	/*
	 * Read GSNs File and compare file with generated  GSNs by SailPoint and created programming GSNs by SailPoint Feed Files 
	 */
	//********************[ Read SailPoint GSN File ]********************************************
	public Set<String> compareSailPointGsnListWithPersonGsnList(String dirLoc,List<String> personGsnList) {
		List<String> sailpointGsnList = new ArrayList<>();
		Set<String> diffGsnList = new HashSet<>();
		
		File fl = new File(dirLoc+"/in/SailPointGSN.csv");
		if(!(fl.exists())) {
			System.out.println("File does not exits on path :"+dirLoc+"/in/SailPointGSN.csv");
			System.exit(0);
		}
		try (BufferedReader br = new BufferedReader(new FileReader(dirLoc+"/in/SailPointGSN.csv"))) {
		    String line;
		    int lineNumber = 0;
		    while ((line = br.readLine()) != null) {
		    	lineNumber=lineNumber+1;
		        String[] values = line.split(COMMA_DELIMITER);
		        int cnt = 0;
		        for(String str:values) {
		        	cnt = cnt+1;
		        	sailpointGsnList.add(str);
		        	
		        }
		    }
		    
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		//-----------------------[ comparing GSNs ]-----------------------------------
		try {
				/*//working block
				 * for(int i=0;i<personGsnList.size();i++) {
					String gsnName=personGsnList.get(i);
					for(int j=0;j<=sailpointGsnList.size();j++) {
						if(j<sailpointGsnList.size() && (sailpointGsnList.get(j).toUpperCase()).startsWith(gsnName.toUpperCase())) {
							break;
						}
						else if (j==sailpointGsnList.size()){
							diffGsnList.add(gsnName);
							//these are 37 GSNs ,Total Match GSNs are = 122
						}
					}
				}*/
				/*
				JOHSX046 # Match found personGsn :JOHSX
				JOHSX045 # Match found personGsn :JOHSX
				GOODX012 # Match found personGsn :GOODX
				GOODX011 # Match found personGsn :GOODX
				*/
				//-------------------------------------------
				for(int i=0;i<sailpointGsnList.size();i++) {
					String gsnName=sailpointGsnList.get(i);
					for(int j=0;j<=personGsnList.size();j++) {		
						if(j<personGsnList.size() && (gsnName.toUpperCase()).startsWith(personGsnList.get(j).toUpperCase())) {
							//System.out.println(gsnName+" # Match found personGsn :"+personGsnList.get(j));
							break;
						}
						else if (j==personGsnList.size()){
							//System.out.println(gsnName+" # Match NOT found");
							diffGsnList.add(gsnName);
						}
					}
				}
				
				for(String gsnSTR:diffGsnList) {
				Files.write(Paths.get(dirLoc+"/output/diffGsnList.csv"),(gsnSTR+",").getBytes(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
				}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return diffGsnList;
	}
	
		
}
