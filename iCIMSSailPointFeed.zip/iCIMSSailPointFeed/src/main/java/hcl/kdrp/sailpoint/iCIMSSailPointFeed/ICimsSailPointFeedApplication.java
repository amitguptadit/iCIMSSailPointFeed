package hcl.kdrp.sailpoint.iCIMSSailPointFeed;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import hcl.kdrp.sailpoint.util.SailPointFeed;
import hcl.kdrp.sailpoint.util.SailPointFeedUtil;

@SpringBootApplication
@ComponentScan(basePackages = {"hcl.kdrp.sailpoint"})
public class ICimsSailPointFeedApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(ICimsSailPointFeedApplication.class, args);
		SailPointFeed feed = context.getBean(SailPointFeed.class);
		
		SailPointFeedUtil util = context.getBean(SailPointFeedUtil.class);
		List<List<String>> personRecords=util.getPersonName(feed.sailpointFeedFileName);
		
		List<String> personGsnList = util.getPersonName(personRecords,feed.sailpointFeedFileName);
		Set<String> diffGsnList = util.compareSailPointGsnListWithPersonGsnList(feed.sailpointFeedFileName,personGsnList);
		System.out.println("Diff GSNs List are : "+diffGsnList);
		
	}
}
